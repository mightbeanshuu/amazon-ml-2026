"""Business entity resolution pipeline."""
